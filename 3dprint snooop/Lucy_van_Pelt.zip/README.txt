                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2515566
Lucy van Pelt by reddadsteve is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Lucy van Pelt, from the comic strip Peanuts by Charles Schulz.

Lucy is characterized as a "fussbudget", crabby, bossy and opinionated girl who bullies other characters in the strip, particularly Linus and Charlie Brown.  While she is not exactly cold-hearted, she can be quite antagonistic, often playing the villain role in a number of stories

The model is in proportion to my Charlie Brown model:
https://www.thingiverse.com/thing:2510789

No supports are required. If you have the proper filament colors, no painting is needed.

The model is 140mm tall.

Enjoy!

# Print Settings

Printer: FlashForge Creator X
Rafts: Doesn't Matter
Supports: No
Resolution: .2mm
Infill: 10%

Notes: 
See below for helpful printing and assembly tips.

# Building the model

## Colors (there are no multiple printed pieces)

Black:
l_hair_right
l_hair_left
l_eyebrows
l_eyes
l_mouth
l_shoes_middle
..
Beige or Flesh:
l_head_top
l_head_bottom
l_arm_left
l_arm_right
l_legs
..
White:
l_shoes_front
l_shoes_back
..
Blue:
l_dress
l_shoulder_right
l_shoulder_left
l_socks
..
Any color (hidden pieces)
l_pins
..

## Printing and assembly tips

Printing tips
1-As with most of my models, no supports are required.

2-Be sure to clean any first layer squish if you have any problem joining parts. The parts should fit nicely when printed cleanly or with a slight first layer squish.

3-I did not require any rafts or brims for any of the parts.

..
Assembly tips:
1-The eyebrows are small and print well but if for some reason you have an issue inserting them into the head (over-extrusion or a squish that cannot be cleaned) simply flip them over and put them in with the flat side facing out.

2-The left/right eyes are interchangeable. There is an up/down positioning of each eye. If it does not look right when inserted just rotate the eye piece for a better fit.

3-The left/right shoulders look similar but are slightly different, so take care when connecting them to the dress.

4-The leg holes in the dress should be positioned toward the back.

5-The left/right shoe parts are not interchangeable but are easy to distinguish which is left and right.

5-Refer to the assembly diagram for putting the model together. The model is meant to be glued.

![Alt text](https://cdn.thingiverse.com/assets/c1/93/37/95/7e/lucy_assembly.jpg)