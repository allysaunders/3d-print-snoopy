                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2792617
Snoopy by reddadsteve is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Snoopy, from the comic strip Peanuts by Charles Schulz.

Snoopy is Charlie Brown's pet beagle.  He is is a loyal, innocent, imaginative and good-natured beagle who is prone to imagining fantasy lives, including being an author, a college student known as "Joe Cool" and a World War I Royal Flying Corps ace. 

Other than some very small supports for one piece, no supports are required. If you have the proper filament colors, no painting is needed.

The assembled model is 190mm tall and is in proportion to the other Peanuts characters that I've previously uploaded:
Charlie Brown: https://www.thingiverse.com/thing:2510789
Lucy van Pelt: https://www.thingiverse.com/thing:2515566
Linus van Pelt: https://www.thingiverse.com/thing:2643426

Enjoy!

# Print Settings

Printer: FlashForge Creator X
Rafts: No
Supports: No
Resolution: .2 mm
Infill: 10%

Notes: 
Note:  I listed this as a 'no support' model, however one piece requires a very small amount of supports.  Refer to the below sections for details.

# Building the Model

## Colors (there are no multiple printed pieces)

Black:
nose
ear_right
ear_left
eye_right
eye_left
text
..
Red:
house_top
house_bottom
collar
..
White:
head
body (see below for minor supports required0
..


## Printing and assembly tips

Printing tips
1-As with most of my models, I strive to make all the pieces support free.  However in this model some supports are required for the body.stl part.  I used .1mm supports with a 60% overhang criteria (depending on your slicer, that could be 30%).  You should only have supports under the arm areas.

2-The parts should fit nicely when printed cleanly or with a slight first layer squish.

3-The eye pieces have very small bases.  Personally, I printed these pieces with a brim.  There is plenty of leeway to insert the eyes so a thorough cleaning of the brim is not required to have the pieces fit.

..
Assembly tips:
1-The left/right eyes and ears are not interchangeable but should be easy to tell which is which.

2-The house contains slight indents for easy positioning of the text characters.

3-Refer to the assembly diagram for putting the model together. The model is meant to be glued.