                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2510789
Charlie Brown by reddadsteve is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Charlie Brown, from the comic strip Peanuts by Charles Schulz.

Personality-wise, he is gentle, insecure, and lovable. Charlie Brown possesses significant determination and hope, but frequently fails because of his insecurities, outside interference, or plain bad luck.

No supports are required. If you have the proper filament colors, no painting is needed.

The model is 140mm tall.

Enjoy!

# Print Settings

Printer: FlashForge Creator X
Rafts: Doesn't Matter
Supports: No
Resolution: .2mm
Infill: 10%

Notes: 
See below for helpful printing and assembly tips.

# Building the model

## Colors (there are no multiple printed pieces)

Black:
c_hair
c_eyebrows
c_eyes
c_mouth
c_stripes
c_pants
..
Beige or Flesh:
c_head_top
c_head_bottom
c_arm_left
c_arm_right
c_legs
..
Brown:
c_shoes
..
Yellow:
c_shirt_top
c_shirt_bottom
c_socks
..
Any color (hidden pieces)
c_pins
..


## Printing and assembly tips

Printing tips
1-As with most of my models, no supports are required.

2-Be sure to clean any first layer squish if you have any problem joining parts. The parts should fit nicely when printed cleanly or with a slight first layer squish.

3-I did not require any rafts or brims for any of the parts.

..
Assembly tips:
1-The eyebrows have the thinner part pointing toward the nose.  The parts are small and print well but if for some reason you have an issue inserting them into the head (over-extrusion or a squish that cannot be cleaned) simply flip them over and put them in with the flat side facing out.

2-The left/right eyes are interchangeable.  There is an up/down positioning of each eye.  If it does not look right when inserted just rotate the eye piece for a better fit.

4-Since I model with the goal of no supports, the angle of the left arm did not allow for a dent into the shirt.  This is not really an issue here, just glue the left arm to the shirt sleeve and an extra dab of glue on his hand were it touches the stripe.

5-Refer to the assembly diagram for putting the model together. The model is meant to be glued.

![Alt text](https://cdn.thingiverse.com/assets/94/f2/0a/a9/ec/charlie_assembly.jpg)
Charlie Brown assembly diagram